//
// measurements.playground
//
// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 11 (Q3 2020) video 07
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Learn about the Measurement system in Foundation and how it can make your life a lot easier.
//  For more code, go to http://bit.ly/AppPieGithub


import Foundation

//Working with measurements
var inches = Measurement(value: 10, unit: UnitLength.inches)
inches + inches
inches / 2
inches.converted(to: .centimeters).value
inches.converted(to: .baseUnit())
let formatter = MeasurementFormatter()
formatter.locale = Locale(identifier: "it_IT")
formatter.unitOptions = .naturalScale
formatter.unitStyle = .long
formatter.string(from: inches)
formatter.string(from: Measurement(value: 1, unit: UnitVolume.liters))
